rm ./outputFileLondon/*
rm ./outputFileBuenosAires/*
rm ./outputFileSanFrancisco/*
rm ./outputFileDefault/*
mv ./inputFileBackup/bankACHCodesLondon.xml.backup ./inputFileBackup/bankACHCodesLondon.xml
mv ./inputFileBackup/bankACHCodesBuenosAires.xml.backup ./inputFileBackup/bankACHCodesBuenosAires.xml
mv ./inputFileBackup/bankACHCodesSanFrancisco.xml.backup ./inputFileBackup/bankACHCodesSanFrancisco.xml
mv ./inputFileBackup/* ./inputFiles/
